You will need:

main.c: 
Write all of your code in this file. 

lcd_driver.c: 
This is the driver for 3pi's LCD, it has the functions that you can call in your main file 
You must call "initialize_LCD_driver()" before trying to use any functions in the driver.

makefile: 
This compiles your program. Enter 'make all' in the command prompt. 
You may need to change the COM port in the makefile (the process covered in lab 7).
